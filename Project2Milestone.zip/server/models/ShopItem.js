/* This file defines our schema and model interface for the account data.

   We first import bcrypt and mongoose into the file. bcrypt is an industry
   standard tool for encrypting passwords. Mongoose is our tool for
   interacting with our mongo database.
*/
// const bcrypt = require('bcrypt');
const mongoose = require('mongoose');

/* When generating a password hash, bcrypt (and most other password hash
   functions) use a "salt". The salt is simply extra data that gets hashed
   along with the password. The addition of the salt makes it more difficult
   for people to decrypt the passwords stored in our database. saltRounds
   essentially defines the number of times we will hash the password and salt.
*/
// const saltRounds = 10;

let ShopItemModel = {};

/* Our schema defines the data we will store. A username (string of alphanumeric
   characters), a password (actually the hashed version of the password created
   by bcrypt), and the created date.
*/
const ShopItemSchema = new mongoose.Schema({
  Name: {
    type: String,
    required: true,
    trim: true,
    unique: true,
    match: /^[A-Za-z0-9_\-.]{1,16}$/,
  },
  currency: {
    type: Number,
    min: 0,
    required: true,
  },
  img: {
    type: String,
    required: true,
    trim: true,
    unique: true,
  },
  createdDate: {
    type: Date,
    default: Date.now,
  },
});

// // Converts a doc to something we can store in redis later on.
// AccountSchema.statics.toAPI = (doc) => ({
//   username: doc.username,
//   _id: doc._id,
// });

// Helper function to hash a password
// AccountSchema.statics.generateHash = (password) => bcrypt.hash(password, saltRounds);

ShopItemModel = mongoose.model('ShopItem', ShopItemSchema);
module.exports = ShopItemModel;
